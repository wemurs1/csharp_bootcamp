﻿namespace GameLibrary;

public record PlayerDto(string Name, int Level, DateTime JoinDate);