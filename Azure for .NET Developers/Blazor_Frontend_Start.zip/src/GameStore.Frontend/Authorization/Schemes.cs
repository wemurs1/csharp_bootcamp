﻿namespace GameStore.Frontend.Authorization;

public static class Schemes
{
    public const string Keycloak = nameof(Keycloak);
    public const string Entra = nameof(Entra);
}