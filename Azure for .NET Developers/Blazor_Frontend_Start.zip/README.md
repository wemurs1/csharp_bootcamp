# Game Store Frontend

Run this in the AppHost project directory:

```powershell
$clientSecret = "CLIENT SECRET HERE"
dotnet user-secrets set "Authentication:Schemes:Entra:ClientSecret" $clientSecret
```