namespace GameStore.Api.Shared.Authorization;

public static class ClaimTypes
{
    public const string Role = "role";

    public const string Scope = "scope";
}
