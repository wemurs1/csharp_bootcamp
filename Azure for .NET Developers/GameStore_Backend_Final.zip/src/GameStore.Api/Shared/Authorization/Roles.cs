namespace GameStore.Api.Shared.Authorization;

public static class Roles
{
    public const string Admin = nameof(Admin);
}
