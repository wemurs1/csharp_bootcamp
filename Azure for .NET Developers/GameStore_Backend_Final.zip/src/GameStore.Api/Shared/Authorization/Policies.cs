namespace GameStore.Api.Shared.Authorization;

public static class Policies
{
    public const string UserAccess = nameof(UserAccess);

    public const string AdminAccess = nameof(AdminAccess);
}
