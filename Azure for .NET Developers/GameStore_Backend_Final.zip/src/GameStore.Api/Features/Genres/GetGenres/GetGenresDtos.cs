namespace GameStore.Api.Features.Genres.GetGenres;

public record GenreDto(Guid Id, string Name);
