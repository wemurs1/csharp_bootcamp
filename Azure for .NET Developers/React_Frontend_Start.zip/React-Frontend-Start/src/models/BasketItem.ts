export interface BasketItem {
    id: string;
    name: string;
    price: number;
    quantity: number;
    imageUri: string;
}