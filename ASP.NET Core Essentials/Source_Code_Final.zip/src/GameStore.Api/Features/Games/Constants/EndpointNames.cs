using System;

namespace GameStore.Api.Features.Games.Constants;

public static class EndpointNames
{
    public const string GetGame = nameof(GetGame);
}
