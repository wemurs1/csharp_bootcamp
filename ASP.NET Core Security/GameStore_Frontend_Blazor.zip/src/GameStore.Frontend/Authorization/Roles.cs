﻿namespace GameStore.Frontend.Authorization;

public static class Roles
{
    public const string Admin = nameof(Admin);
}
