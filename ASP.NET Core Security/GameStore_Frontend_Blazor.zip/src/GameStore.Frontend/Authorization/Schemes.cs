﻿namespace GameStore.Frontend.Authorization;

public static class Schemes
{
    public const string Keycloak = nameof(Keycloak);
}