namespace GameStore.Api.Shared.Authorization;

public static class Schemes
{
    public const string Keycloak = nameof(Keycloak);
}
