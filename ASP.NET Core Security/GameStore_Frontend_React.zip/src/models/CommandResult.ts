export interface CommandResult {
    succeeded: boolean;
    errors: string[];
}