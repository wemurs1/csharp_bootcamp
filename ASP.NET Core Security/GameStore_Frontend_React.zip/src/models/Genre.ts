export interface Genre {
    id: string;
    name: string;
}