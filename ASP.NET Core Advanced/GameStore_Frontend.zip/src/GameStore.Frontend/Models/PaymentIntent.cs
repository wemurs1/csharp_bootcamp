﻿namespace GameStore.Frontend.Models;

public class PaymentIntent
{
    public required string ClientSecret { get; set; }
}
