namespace GameStore.Api.Features.Games.Constants;

public static class StorageNames
{
    public const string GameImagesFolder = "GameImages";
}
